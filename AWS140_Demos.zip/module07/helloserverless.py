def lambda_handler(event, context):
    print("In lambda handler")
    
    resp = {
        "statusCode": 200,
        "headers": {
            "Access-Control-Allow-Origin": "*",
        },
        "body": "Neil - Serverless Architecture Demo deployed successfully - Developing on AWS Course"
    }
    
    return resp